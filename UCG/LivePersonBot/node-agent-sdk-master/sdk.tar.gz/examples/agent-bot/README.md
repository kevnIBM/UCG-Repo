see [example explanation](https://livepersoninc.github.io/node-agent-sdk/agent-bot.html)
