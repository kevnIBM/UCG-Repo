See [example documentation](https://livepersoninc.github.io/node-agent-sdk/cluster.html)
