'use strict';

const Agent = require('./lib/AgentSDK');

module.exports = {
    Agent
};
